# County Cricket — Tabletop Edition
## Migration Doc · Session 6

---

## Current File State
- `index.html` — v9 base + all Session 6 changes
- `sim.js` — updated with all Session 6 sim changes

---

## Session 6 Changes

### 1. Hard CPU — Par-Aware Batting (Innings 1)
`smartHumanMentality()` now targets 110% of par score for conditions.

Rolling target recalculated each ball with ±10 run buffer bands:
- **>10 ahead of pace** → drop one mentality level (consolidate)
- **Within ±10** → play normally per existing overs/wickets logic
- **>10 behind pace** → lift one mentality level (push)

Buffer activates after over 1 (ball 7+) to avoid early twitchiness.

---

### 2. Hard CPU — Smart Chase (Innings 2)
`smartHumanMentalityChase()` now targets **required run rate + 0.5 RPO** rather than matching exactly.

Thresholds tightened — CPU stays at `positive` for most of the chase, only escalates to `aggressive` when truly desperate (rrTarget > 13). This prevents the CPU from slogging itself out chasing a comfortable target.

---

### 3. Hard CPU — Par-Aware Bowling Field (Innings 1)
`smartHumanField()` innings 1 now checks `getRunsAheadOfPar()`:
- Batting team **>10 ahead** of par → attacking field (take wickets)
- Batting team **>10 behind** → defensive (let them take risks)
- Within ±10 → falls through to positional logic

---

### 4. Hard CPU — Wicket-Aware Defensive Field (Innings 2)
`smartHumanField()` innings 2 logic inverted and made wicket-aware:
- `(rrRequired > 11 && wickets < 7) || rrRequired > 14` → defensive (save boundaries, chaser is slogging)
- `rrRequired < 6` → attacking (chaser is comfortable, take wickets)
- Otherwise → balanced

Key insight: "attacking" field = close catchers = more run scoring opportunity for batter. When chaser is desperate, defensive field is correct to save boundaries.

---

### 5. CRR / Req. RR Scoreboard Display
Two new cells added to the scoreboard panel (second row, each spanning 2 of 4 columns):
- **CRR** — current run rate, shown all game
- **Req. RR** — required run rate, shown in innings 2 only (shows `—` in innings 1)

---

### 6. No-Ball Mechanic
When the bowling team reviews a **not-out LBW or Caught Behind** decision, there is a **10% chance** the third umpire spots a no-ball:

- +1 run awarded to batting team
- Ball does NOT count — `st.ball` wound back, `overBalls` popped
- Review **retained** (no-ball was the issue, not a wrong call)
- `st.freeHit = true` set

No-ball on ball 6 → same bowler bowls again (natural, no special handling needed).

Four commentary lines each for LBW and Caught Behind variants.

---

### 7. Free Hit
After a no-ball, next ball is a free hit:

- Announced: `🟡 FREE HIT — [batsman] can only be dismissed by a run-out!`
- Run face: `[2,4,4,6,6,6]` — explosive scoring
- Only 4% run-out dismissal chance
- `st.freeHit` cleared after ball resolves
- `st.freeHit` also cleared on innings reset (line: `st.reviewsLeft=2;st.bowlingReviewsLeft=2;st.activeUmpIdx=0;st.freeHit=false;`)

---

### 8. Specialist Bonus → Multiplier (1.10×)
`getSpecialistBonus()` now returns `0` always. Replaced by `getSpecialistMult()` which returns `1.10` when specialist is in their element (opener overs 1-2, finisher overs 9-10, etc).

Applied as a **howzat multiplier** rather than a star bump:
```js
howzatChance = getHowzatPct(effectiveStars) * getBowlerStarsMod(bwl) * fat.howzatMod * getSpecialistMult(bwl);
```

Effect: ~10% howzat boost vs ~24% from old full-star bump on a 4★ bowler. Openers remain dangerous without being devastating.

"★ In their element" UI tag updated to use `getSpecialistMult(bwl) > 1` check.

Same change applied to `sim.js`.

---

## Sim Results (Session 6 final · 5000 games)

### Baseline
| Condition | Inn1 avg | Bats1st% | LastOver% |
|---|---|---|---|
| Minefield/Sunny | 86.1/7.8 | 50% | 47% |
| Minefield/Overcast | 76.0/8.8 | 49% | 24% |
| Minefield/Damp | 88.4/7.1 | 49% | 60% |
| Good/Sunny | 91.9/6.7 | 51% | 68% |
| Good/Overcast | 85.3/7.7 | 50% | 48% |
| Good/Hot | 92.1/6.4 | 49% | 73% |
| Good/Damp | 97.8/5.5 | 49% | 84% |
| Flat/Sunny | 96.0/4.7 | 48% | 92% |
| Flat/Overcast | 91.8/6.3 | 50% | 74% |
| Flat/Hot | 98.7/3.8 | 49% | 97% |
| Flat/Damp | 91.8/5.9 | 49% | 78% |

### Smart (Hard CPU)
| Condition | Inn1 avg | Bats1st% | LastOver% |
|---|---|---|---|
| Minefield/Sunny | 85.7/7.3 | 50% | 38% |
| Minefield/Overcast | 75.9/8.4 | 50% | 19% *(structural)* |
| Minefield/Damp | 87.4/6.7 | 49% | 50% |
| Good/Sunny | 92.1/6.7 | 54% | 58% |
| Good/Overcast | 84.6/7.7 | 52% | 40% *(overcast accepted)* |
| Good/Hot | 92.7/6.5 | 55% | 63% |
| Good/Damp | 98.5/5.8 | 56% | 74% |
| Flat/Sunny | 98.1/4.9 | 55% | 86% |
| Flat/Overcast | 92.9/6.4 | 55% | 66% |
| Flat/Hot | 102.6/4.0 | 56% | 94% |
| Flat/Damp | 93.1/5.9 | 54% | 70% |

**Accepted structural exceptions:**
- Minefield/Overcast LastOver% ~19% — small targets resolved early, realistic
- Minefield/Sunny LastOver% ~38% — same reason
- Overcast conditions generally lower LastOver% — accepted

---

## Pending / Next Session
- CPU bowler interstitial auto-skip (still pending from Session 5)
- Field spam cooldown for Easy CPU (still pending)
- Good/overcast win% trim (still pending)
- Minefield personality exploit re-sim (still pending)

---

## Input Count
Session 6 ended at Input 25.
Next session starts at Input 1 (resets each chat).

---

## Session 7 Changes

### 1. CPU Bowler Setup — Silent
Removed "CPU choosing bowler" fallback text from bowler card in both the bowling screen and batting screen. `applyCpuBowlerIfNeeded()` already runs eagerly at top of `renderBowlingScreen()` so bowler is always set before render. Dead text removed.

### 2. CPU Batting — Wicket Pause
`renderPendingWicket()` CPU batting branch replaced auto-firing `setTimeout` with a **Continue →** button. Human now reads the dismissal commentary and taps to bring in the next batsman.

### 3. Specialist Multiplier Trimmed
`getSpecialistMult()` in `index.html` and inline `specMult` in `sim.js`: all cases `1.10 → 1.05`.
Affects: opener, finisher, strike, swing, seamer, tailkiller.

### 4. One-of-Each Specialism (Team Editor)
Specialism buttons in team editor now grey out (`opacity:0.35`, `disabled`) for any specialism already taken by another bowler in the same team. `'none'` is always available. The player's own active specialism is never greyed for themselves.

### 5. All 11 Teams Mirrored into sim.js
`sim.js` previously had only 2 teams (Arkaba XI, Feathers CC). Now has all 11 stock teams, identical to `index.html`. All teams audited — no duplicate specialisms found.

---

## ⚠️ Standing Rule
**The SIM must always mirror the game's stock teams exactly.** Any time teams are added, renamed, or modified in `index.html`, the same change must be applied to `sim.js` immediately. Otherwise sim results are testing different matchups to the actual game.

---

## Pending / Next Session
- Field spam cooldown for Easy CPU (still pending)
- Good/overcast win% trim (still pending)
- Minefield personality exploit re-sim (still pending)
- Re-sim recommended after specialist multiplier trim (1.10 → 1.05)

---

## Input Count
Session 7 ended at Input 8.
Next session starts at Input 1 (resets each chat).

---

## Session 7 continued — Inputs 9-20

### Sim Runner Built
Standalone sim_v3/v4/v5/v6/v7.html built for in-browser simulation.
- All 11 teams vs all 11 conditions, 50 games/scenario
- Shows Inn1 avg, P10-P90, Bats1st%, Margin median, P25-P75, Ov8-10 wins%
- Win-over breakdown table (which over bat2nd wins)
- Copy as text button

### Specialist Multiplier 1.10 -> 1.05
Applied in both index.html and sim.js (Session 7 input 8).

### Defensive Mentality Fix
MENTALITY_FIELD_HZ defensive row:
- attacking: 1.30 -> 0.85 (survival strategy, not punished)
- balanced: 0.72 -> 0.58 (meaningful protection)
- defensive: 0.58 -> 0.45 (very safe)

SIM updated to match: mentality mod converted from additive to multiplicative
(0.58 / 0.86 / 1.00 / 1.18) mirroring game's balanced-field column.

### Defensive Field Fatigue Cap — PENDING SIM
getFieldFatigue() defensive runMod cap at 1.20 proposed.
Was uncapped (reaching 1.60+ by over 8, inflating 2s into 4s via multiplier stack).
NOT committed to index.html — awaiting sim validation before applying.

### Batting Stars — PENDING HTML
All top-6 batsmen bumped to 4-star in sim.js and sim runner (v7).
NOT yet applied to index.html — awaiting sim results confirmation.

### Margins Problem — Ongoing
Median win margin consistently 35-41r across all conditions.
Root cause: structural T20 advantage of batting first + wicket rate when chasing.
Decision: will NOT apply howzat buffs (breaks decision integrity).
Solution path: Setting/Chasing/Balanced team personalities to create different
worm shapes and reward different playstyles legitimately.

### Team Builder Created
Standalone team_builder.html for designing teams visually.
Matches game UI — batting tab (drag to reorder), bowling tab, specialism enforcement.
Personality selector (Balanced/Setting/Chasing).
Export Code button outputs ready-to-paste makeTeam() format.

---

## Standing Rules
1. SIM must always mirror game teams exactly.
2. Always sim before committing changes to index.html.
3. Both index.html and sim.js must stay in sync on all mechanical changes.

---

## Pending / Next Session
- Apply new team designs once built in team_builder (Setting/Chasing/Balanced identities)
- Implement personality mechanical effects (worm shape logic in smart mentality)
- Defensive field fatigue runMod cap (sim first)
- Field spam cooldown for Easy CPU
- Good/overcast win% trim
- Minefield personality exploit re-sim

---

## Input Count
Session 7 ended at Input 20.
Next session starts at Input 1 (resets each chat).

---

## Session 8 — Full Log

### Standing Rules (reminder)
1. SIM must always mirror game teams exactly
2. Always sim before committing changes to index.html
3. Both index.html and sim.js must stay in sync on all mechanical changes

### Changes Committed This Session

#### Style System Overhaul
Old styles (Conservative, Balanced, Aggressive, Ultra-Agg, Slogger) replaced with:
- Defensive (was Conservative) — vs_fast:1.15, vs_spin:0.72
- Rotation (was Balanced) — vs_fast:1.0, vs_spin:1.0
- Positive (was Aggressive) — vs_fast:0.85, vs_spin:1.2
- Aggressive (was Ultra-Agg) — vs_fast:0.8, vs_spin:0.8
- Slogger removed entirely. Former Slogger players → Aggressive.
Styles now map 1:1 with mentality names.

#### Style/Mentality Match Bonus
When a batter's style matches their current mentality: +10% not-out chance.
Applied in rollNotOut() in index.html and in sim.js not-out calculation.
Same as bowling specialist mult pattern — consistent, not gameable.

#### Defensive Mentality Fix (MENTALITY_FIELD_HZ)
defensive/attacking: 1.30 → 0.85 (survival strategy, not punished)
defensive/balanced: 0.72 → 0.58 (meaningful protection)
defensive/defensive: 0.58 → 0.45 (very safe)
SIM: mentality mod converted from additive to multiplicative (0.58/0.86/1.00/1.18).

#### Defensive Field Fatigue Cap
getFieldFatigue() defensive runMod capped at 1.20 (was uncapped, reaching 1.60+ by over 8).
Prevented 2s inflating into 4s/6s via multiplier stack.

#### Minefield Run Face Tables
No sixes on Minefield ever. Tables:
- attacking: [0,1,1,2,2,4] — batters swinging, no sixes
- balanced: [0,0,1,1,2,4] — sensible scoring
- defensive: [0,0,0,1,2,2] — survival
In index.html getMentalityRunFaces: defensive mentality on Minefield gets
its own safer tables regardless of field setting (human player protection).
In sim.js: flat Minefield table regardless of mentality (CPU balance).

#### Minefield Not-Out Bump
3-star Minefield not-out: 22 → 26 (all weather columns)
4-star Minefield not-out: 34 → 38 (all weather columns)
Applied to both DEFAULT_NOTOUT in index.html and NO in sim.js.

#### Minefield Par Target
CPU batting first on Minefield targets 105% of par (other pitches 110%).
More modest target leaves chaseable total.
In sim.js: parMult = pitchId==='minefield' ? 1.05 : 1.10
In index.html: same in smartHumanMentality par-aware band.

#### CPU Toss — Minefield Always Bats First
CPU always bats first on Minefield (was 70% preference).
Human wins toss: sees recommendation hint (Bat First ⚡ / Bowl First ⚠).

#### Top-6 Batting Stars → 4★
All 29 top-6 players previously at 3★ bumped to 4★.
Applied to all 11 teams in both index.html and sim.js.

#### Bowl Stars Budget → 17
Team editor budget changed from 18 → 17 bowl stars.
Forces real trade-off: 5★ bowler requires a 2★ somewhere.
(index.html team editor only — sim doesn't enforce budget)

#### Wicket Ceiling — Collapse Intelligence
CPU mentality capped based on wickets lost. Prevents reckless aggression after collapse.
Applied via applyWicketCeiling() in both files:
- 0-2 lost: full range
- 3-4 lost, before over 6: max Positive (no Aggressive)
- 5-6 lost, before over 8: max Rotation
- 7+ lost: Defensive only
- Over 8, ≤5 lost: Positive unlocks
- Over 9, ≤6 lost: Aggressive unlocks
Human player is NOT restricted — this is CPU intelligence only.

#### Team Builder Tool
Standalone team_builder.html created. Matches game UI.
Batting tab (drag to reorder), bowling tab, specialism enforcement.
Personality selector (Balanced/Setting/Chasing).
Export Code button outputs ready-to-paste makeTeam() format.
17★ bowl budget enforced in editor.

### Final Sim Results (v16 — accepted baseline)
Minefield: avg 79-81, Bats1st 64-68% (accepted — bowler's pitch, bat first is correct)
Good: avg 93-101, Bats1st 54-56%, margins 31-34r, Ov8-10 86-92%
Flat: avg 97-105, Bats1st 54-57%, margins 31-34r, Ov8-10 90-93%
Win-over distribution healthy everywhere. Margins best ever seen (31-34r).

### Pending / Next Session
- Setting/Chasing personality worm logic (CPU mentality shaped by team identity)
- Redesign all 11 teams using team_builder with Setting/Chasing/Balanced identities
- Field spam cooldown for Easy CPU (long-pending)
- Good/overcast win% trim (long-pending, now borderline acceptable at 56%)
- Minefield personality exploit re-sim (long-pending)

---

## Input Count
Session 8 ended at Input 40+.
Next session starts at Input 1 (resets each chat).
